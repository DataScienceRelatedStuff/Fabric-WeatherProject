# Fabric notebook source

# METADATA ********************

# META {
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "ad79a8f2-6b81-42f3-a5aa-4a0c9fad05f2",
# META       "default_lakehouse_name": "LH_WeatherData",
# META       "default_lakehouse_workspace_id": "841410bd-acd7-4c95-9f74-609cd2677f4d"
# META     },
# META     "environment": {
# META       "environmentId": "3d8cc76a-e996-4b94-8e86-6b30c015c6d4",
# META       "workspaceId": "841410bd-acd7-4c95-9f74-609cd2677f4d"
# META     }
# META   }
# META }

# MARKDOWN ********************

# Lakehouse data validation with Great Expectations in Microsoft Fabric

# MARKDOWN ********************

# https://www.youtube.com/watch?v=jrcr28HGtEA&list=PLug2zSFKZmV1NvKfnRzG9e3Fl-8QLD5MK&index=6

# CELL ********************

import great_expectations as gx

context = gx.get_context()

context.add_or_update_expectation_suite("my_expectation_suite")

