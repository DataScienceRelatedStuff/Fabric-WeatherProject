# Fabric notebook source

# METADATA ********************

# META {
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "ad79a8f2-6b81-42f3-a5aa-4a0c9fad05f2",
# META       "default_lakehouse_name": "LH_WeatherData",
# META       "default_lakehouse_workspace_id": "841410bd-acd7-4c95-9f74-609cd2677f4d",
# META       "known_lakehouses": [
# META         {
# META           "id": "ad79a8f2-6b81-42f3-a5aa-4a0c9fad05f2"
# META         }
# META       ]
# META     }
# META   }
# META }

# MARKDOWN ********************

# **# USING FABRIC NOTEBOOK TO CLEAN AND TRANSFORM DATA**
# 
# https://www.youtube.com/watch?v=4S-IocL9Glo&list=PLug2zSFKZmV1NvKfnRzG9e3Fl-8QLD5MK&index=3


# MARKDOWN ********************

# STEP 1: Load from JSON to pySpark dataframe

# MARKDOWN ********************

# **<mark>DEFINE PARAMETER</mark>**

# PARAMETERS CELL ********************

PM_file_path = ""
#PM_file_path = "Files/2024/"
#20240429weather.json"

#print(PM_file_path)

#https://www.youtube.com/watch?v=Rmf7-WOcouE


# CELL ********************

from datetime import datetime

dt_now = datetime.now()
dt_string = dt_now.strftime("%Y%m%d")

dynamic_file_path = PM_file_path + f"{dt_string}weather.json"
#print(dynamic_file_path)


# MARKDOWN ********************

# **ORIGINAL**

# CELL ********************

"""
####DAILY FOLDER
#Define path to JSON file
#Files/2024/04/29
#Files/2024/04/29/Weather.json
json_file_path = "Files/2024/04/29/Weather.json"

#Load data into DataFrame
df = spark.read.json(json_file_path)

####YEARLY FOLDER
#Load data into DataFrame
json_file_path = "Files/2024/20240501weather.json"
df_YearlyFolder = spark.read.json(json_file_path)
"""


# MARKDOWN ********************

# print(json_file_path)
# display(df)
# 
# display(df_YearlyFolder)

# MARKDOWN ********************

# <mark>**<mark>MAKE IT DYNAMIC</mark>**</mark>


# CELL ********************

"""
from datetime import datetime

def read_in_todays_date():
    
    ##INITIAL:
    #Define filepath baesd on today's date

    dt_now = datetime.now()
    #current date = 01/05/2024

    dt_string = dt_now.strftime("%Y/%m/%d")
    #American dateformat

    dynamic_file_path = f"Files/{dt_string}/weather.json"
    print(dynamic_file_path)

    try:
        df = spark.read.json(dynamic_file_path)
        return df
    except Exception as err:
        print(err)


df = read_in_todays_date()
"""

# CELL ********************

from datetime import datetime

def read_in_todays_date():    

    try:
        #df = spark.read.json(PM_file_path)
        df = spark.read.json(dynamic_file_path)
        return df
    except Exception as err:
        print(err)


df = read_in_todays_date()

# CELL ********************

#display(df)

# MARKDOWN ********************

# STEP 2: Cleaning and validation of data
# 
# - flatten file
# - convert temperature to F & C
# - rounding
# - convert unix datetime
# - make code more robust

# CELL ********************

"""
from pyspark.sql.functions import col

flattened_df = df.select(
    col("dt").alias("datetime"),
    col("coord.lat").alias("geo_latitude"),
    col("coord.lon").alias("geo_longitude"),
    col("main.temp").alias("temperature")
)

flattened_df.printSchema()
"""

# CELL ********************

#display(flattened_df)

# CELL ********************

"""
from pyspark.sql.functions import col, to_timestamp

adjusted_df = df.select(
    to_timestamp(col("dt")).alias("datetime"),
    col("coord.lat").alias("geo_latitude"),
    col("coord.lon").alias("geo_longitude"),
    col("main.temp").alias("temperature_kelvin"),
    ((col("main.temp")*9/5) - 459.67).alias("temperature_fahrenheit"),
    (col("main.temp")-273.15).alias("temperature_celsius")
)

adjusted_df.printSchema()
display(adjusted_df)
"""

# CELL ********************

"""
from pyspark.sql.functions import col, to_timestamp, round

adjusted_df = df.select(
    to_timestamp(col("dt")).alias("datetime"),
    col("coord.lat").alias("geo_latitude"),
    col("coord.lon").alias("geo_longitude"),
    col("main.temp").alias("temperature_kelvin"),
    (round((col("main.temp")*9/5) - 459.67,2)).alias("temperature_fahrenheit"),
    (round(col("main.temp")-273.15,2)).alias("temperature_celsius")
)

adjusted_df.printSchema()
display(adjusted_df)
"""

# CELL ********************

from pyspark.sql.functions import col, to_timestamp, round

def convert_unix_to_datetime(unix_datetime_col):
    return to_timestamp(unix_datetime_col)

def temperature_converion(kelvin_col, to_unit):
    if to_unit == "celsius":
        return round(kelvin_col - 273.15,2)
    elif to_unit == "fahrenheit":
        return round((col("main.temp")*9/5) - 459.67,2)

adjusted_df = df.select(
    convert_unix_to_datetime(col("dt")).alias("datetime"),
    col("coord.lat").alias("geo_latitude"),
    col("coord.lon").alias("geo_longitude"),
    col("main.temp").alias("temperature_kelvin"),
    temperature_converion(col("main.temp"), to_unit="fahrenheit").alias("fahrenheit"),
    temperature_converion(col("main.temp"), to_unit="celsius").alias("celsius")
)

#adjusted_df.printSchema()
#display(adjusted_df)

# MARKDOWN ********************

# STEP 3 : Load DataFrame into LakeHouse
# 
# Append

# CELL ********************

adjusted_df.write.format("delta").mode("append").save("Tables/hist_weather")
